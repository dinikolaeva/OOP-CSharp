﻿namespace _07.MilitaryElite.Enumerations
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}

﻿using _06.FoodShortage.Core;

namespace _06.FoodShortage
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}

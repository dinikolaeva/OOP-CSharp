﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.BorderControl.Interfaces
{
    public interface Id
    {
        public string Id { get; set; }
    }
}

﻿using _04.BorderControl.Core;
using System;

namespace _05.BirthdayCelebrations
{
    public class StrartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}

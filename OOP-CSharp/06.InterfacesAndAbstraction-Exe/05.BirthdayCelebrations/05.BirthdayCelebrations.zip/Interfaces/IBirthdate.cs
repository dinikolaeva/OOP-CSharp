﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.BorderControl.Interfaces
{
    public interface IBirthdate
    {
        public string Birthdate { get; set; }
    }
}

﻿namespace _03.Telephony
{
    public interface IBrowse
    {
        string Browsing(string url);
    }
}

﻿using _01.Vehicles.Core;

namespace _02.VehiclesExtension
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}

﻿namespace _04.WildFarm.Foods
{
    public class Fruit : Food
    {
        public Fruit(int quantity) : base(quantity)
        {

        }
    }
}

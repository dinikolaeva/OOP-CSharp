﻿namespace _04.WildFarm.Foods
{
    public class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {

        }
    }
}
